Installtion
1. Install the Alldnn.news_xx_Pa.zip like regular Module
2. Create a page called "News Admin"
3. Place "Alldnn_news_list" module on the left pane
4. Place "Alldnn_news_permission" module on the content pane. (has to be in the same page as Alldnn_news_list"
5. Select "Manage category" from left, and add couple categories you want
6. Select "Manage template" from left, click "Import", browse to 80054Template.xml, Click import. You should see 9 templates imported.
7. Create a news page, and add "Alldnn_news_article" module
8. Repeat Step 7 to create couple more pages include "alldnn_news_article" module
9. Goto "News Admin" page, and set the permission and category for each alldnn_news_article module

Import News from Ventrian News Article module
1. Install 80017 News Artivle Import Export module to a site with Ventrian news.
2. Export the ventrian news, and save it in a local xml file
3. Install 80017 News Article Import Export Module in the new site with 80054 Simple News
4. Click "Import News" and follow the instruction to import all news.
5. The Category will automatically created if you select create category, an article belong to multi-category will be added more than once to the 80054 Simple News under different category.
6. Goto "Alldnn_news_permission" page to set which category and template to display.
