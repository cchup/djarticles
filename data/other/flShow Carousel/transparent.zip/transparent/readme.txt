flShow Carousel 2.0

You can use this slideshow in your personal web pages for free. If you like it
please support flShow with a donation (or at least invite me a pizza).

If you use this slideshow for commercial purposes, you have to support flShow
with a donation proportional to the "added value" that the slideshow brings
to your pages.

Everything is provided as is; I take no responsibility for anything deriving
from the use of this slideshow. Do not use it with pornography, blasphemy,
or other offending material.

Visit http://www.flshow.net/ for more information.