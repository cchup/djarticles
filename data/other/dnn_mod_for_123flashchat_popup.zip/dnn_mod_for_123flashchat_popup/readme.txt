** DotNetNuke: Web Portal System                                        **
** DotNetNuke Chat Module for 123 Flash Chat software                   **
** ==============================================                       **
**                                                                      **
** Copyright (c) by TopCMM 					        **
** Daniel Jiang (support@123flashchat.com)          			**
** http://www.topcmm.com						**
** http://www.123flashchat.com                                          **
**                                                                      **
**                                                                      **
**************************************************************************


####################################################################################################################
## Notes:                                                                                                         ##
##                                                                                                                ##
##     IMPORTANT!!!!                                                                                              ##
##     If you need to use the chat service on a local machine, before installing this module, please              ##
##     download 123 Flash Chat software first from this page:                                                     ##
##     http://www.123flashchat.com/download.html                                                                  ##
##     You may get the latest free demo version of 123 flash chat software there.                                 ##
##                                                                                                                ## 
##     And get professional support from: http://www.123flashchat.com/support.html                                ##
##     We provide email support, online live support, and phone support, etc                                      ##
##                                                                                                                ##
##     Good luck on your business and have a nice day!                                                            ##
##                                                                                                                ##
####################################################################################################################
## Before Adding This MOD To Your DotNetNuke, You Should Back up All the Files Related to This MOD.               ##
####################################################################################################################

Step 1, Install chat module files to your DotNetNuke:
Log in the system with your host account and click Host-->Module definitions in sequence. Then it will take you to the Module Definition page. On the bottom of it, there is an ��Install Module�� button and click it to finish the installation process according to the prompts.

Step 2, Configure chat module's running mode:
After install completion, please copy client folder from <123flashchat installation directory> to <dotnetnuke installation directory>/DesktopModules\topcmm_123flashchat.

Next, let��s go back to that page. On the top of it, you will see the module management panel. Please select 123flashchat in the Module dropdown list, allocate the position to display this module, and click ��add module to page��. Then you will see it on the current page.

Click the small icon near its corresponding module to enter the editing mode, then you can modify some settings of that module under the mode.

There are three editions for the module as follows:
1. Standard
Select Standard in the 123flashchat type dropdown list, input the 123 Flash Chat installation path (for instance: C:\Program Files\123FlashChatServer7.6) to the 123 Flash Chat installed directory textbox. Then click the Integration button near the textbox to complete integration.

Notes: 1. Please make sure the aspnet account has the read-and-write authorization under the folder C:\Program Files\123FlashChatServer7.4\server
       2. Due to the server's restarting, the integration may not take into effect at once.

2. Host 
Select "Host" in the 123flashchat type dropdown list and input your host address into the Host Address textbox (such as http://host71200.123flashchat.com/xxx), then click the "Authorize URL" button to gain a authorize URL and click��update��button.
Go to the Admin Panel of the 123 Flash Chat. Click System Settings and Integration Panel in sequence and select "URL" in the dropdown list. Clicking the "Edit" button near it, a URL textbox will appear and input the URL there. Finally, click "OK" to accomplish integration.

3. Free
Input your room name in Room Name textbox, then click��update��button to finish the process.

Special remark: for free edition, it doesn't offer integration but it will keep your current account in 123 Flash Chat.
