var so = null;
    function CloseLinkPopup(ElemID)
    {
        var divReferencePopup = document.getElementById(ElemID);
        var divReferenceItemView = divReferencePopup.getElementsByTagName("DIV")[0];
        while(divReferenceItemView.firstChild) { divReferenceItemView.removeChild(divReferenceItemView.firstChild); } 
        divReferencePopup.style.display = "none" 
        so= null;
    }
    function UpdatePopupPosition(evt,divReferencePopup)
    {
        var posx = 0;
        var posy = 0;
        var e = evt;
        if (e.pageX || e.pageY) 	{
        posx = e.pageX;
        posy = e.pageY;
        }
        else if (e.clientX || e.clientY) 	{
        posx = e.clientX + document.body.scrollLeft
        + document.documentElement.scrollLeft;
        posy = e.clientY + document.body.scrollTop
        + document.documentElement.scrollTop;
        }
  

        if (posx+divReferencePopup.clientWidth>document.body.clientWidth)
            posx = posx-divReferencePopup.clientWidth;
        if (posy+divReferencePopup.clientHeight>document.body.clientHeight)
            {
         //    alert(document.body.clientHeight);
             posy = posy-divReferencePopup.clientHeight;     
             }
        divReferencePopup.style.left = posx+"px";
        divReferencePopup.style.top = posy+"px";
    }
    function OpenLinkPopup(evt, ElemID, thumb, orig, standard)
    {     
        var divReferencePopup = document.getElementById(ElemID);
        var  divReferenceItemView = divReferencePopup.getElementsByTagName("DIV")[0];
        var  divInfo = divReferencePopup.getElementsByTagName("p")[0];
        var  spanGalleryItemThumb = divReferencePopup.getElementsByTagName("SPAN")[0];
        var  spanGalleryItemOrig = divReferencePopup.getElementsByTagName("SPAN")[1];
        var  spanGalleryItemStand = divReferencePopup.getElementsByTagName("SPAN")[2];
        while(divReferenceItemView.firstChild) { divReferenceItemView.removeChild(divReferenceItemView.firstChild); }                
        
        spanGalleryItemThumb.innerHTML = thumb;
        spanGalleryItemOrig.innerHTML = orig;
        spanGalleryItemStand.innerHTML = standard;

        divReferencePopup.style.visibility = "hidden";
        divReferencePopup.style.display = "block" 
        
        UpdatePopupPosition(evt,divReferencePopup);
        divReferencePopup.style.visibility = "visible";
    }


