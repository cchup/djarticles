﻿function show_gravatar(x) {

    document.getElementById('img_gravatar').src = 'http://www.gravatar.com/avatar/3b3be63a4c2a439b013787725dfce802'

}