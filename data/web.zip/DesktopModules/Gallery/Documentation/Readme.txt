DotNetNuke.Modules.Gallery (MediaGallery) Module

Gallery version 4.03.00 requires DNN 4.09.03 and higher.

Install/UnInstall:
	Install/UnInstall it just like any other DNN module

